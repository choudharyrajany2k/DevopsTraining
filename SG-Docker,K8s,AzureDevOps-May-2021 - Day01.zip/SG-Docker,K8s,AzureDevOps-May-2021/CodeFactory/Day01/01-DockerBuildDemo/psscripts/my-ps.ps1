$PSVersionTable
Get-ChildItem c:\Windows

1..100 | ForEach-Object{
    [System.Threading.Thread]::Sleep(100)
    Write-Host -ForegroundColor Yellow $_
}


