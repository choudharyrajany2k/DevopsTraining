docker image build --tag sriniiyer/nanoserver-ps-app:V10 .
